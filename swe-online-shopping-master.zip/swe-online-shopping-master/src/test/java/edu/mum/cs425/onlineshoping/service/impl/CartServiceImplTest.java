package edu.mum.cs425.onlineshoping.service.impl;

//

//import org.junit.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//
//import static org.junit.Assert.*;
//
///**
// * 
// */
//public class CartServiceImplTest {
//
//    @Autowired
//    CartService cartService;
//    @Test
//    public void addItem() {
//    }
//
//    @Test
//    public void removeItem() {
//    }
//
//    @Test
//    public void updateQuantity() {
//    }
//
//    @Test
//    public void findAll() {
//    }
//
//    @Test
//    public void checkout() {
//    }
//
//    @Test
//    public void getTotal() {
//    }
//}